# expo-multiple-imagepicker
multiple image selecting package for expo


working example path : example/index.js
